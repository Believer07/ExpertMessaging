package servercon;

public interface WebServer {

String MYSERVER = "http://localhost:8080/ExpertMessaging";    
}
