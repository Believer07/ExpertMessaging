package dbcon;

public interface DatabaseDetails {

    String DRIVER = "com.mysql.jdbc.Driver";
    String CONSTR = "jdbc:mysql://localhost:3306/expertmessagingdb";
    String USERID = "root";
    String PASS = "";
}
